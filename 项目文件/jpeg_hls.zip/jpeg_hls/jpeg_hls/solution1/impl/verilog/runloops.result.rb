$Footmark = "FPGA_Xilinx"
$Description = "by Vivado"


#=== Resource usage ===
$SLICE = "1380"
$LUT = "2909"
$FF = "1623"
$DSP = "0"
$BRAM ="64"
$SRL ="0"
#=== Final timing ===
$TargetCP = "10.000"
$CP = "10.357"
