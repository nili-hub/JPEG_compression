#include "hls_design_meta.h"
const Port_Property HLS_Design_Meta::port_props[]={
	Port_Property("ap_clk", 1, hls_in, -1, "", "", 1),
	Port_Property("ap_rst_n", 1, hls_in, -1, "", "", 1),
	Port_Property("s_axi_a_AWVALID", 1, hls_in, -1, "", "", 1),
	Port_Property("s_axi_a_AWREADY", 1, hls_out, -1, "", "", 1),
	Port_Property("s_axi_a_AWADDR", 18, hls_in, -1, "", "", 1),
	Port_Property("s_axi_a_WVALID", 1, hls_in, -1, "", "", 1),
	Port_Property("s_axi_a_WREADY", 1, hls_out, -1, "", "", 1),
	Port_Property("s_axi_a_WDATA", 32, hls_in, -1, "", "", 1),
	Port_Property("s_axi_a_WSTRB", 4, hls_in, -1, "", "", 1),
	Port_Property("s_axi_a_ARVALID", 1, hls_in, -1, "", "", 1),
	Port_Property("s_axi_a_ARREADY", 1, hls_out, -1, "", "", 1),
	Port_Property("s_axi_a_ARADDR", 18, hls_in, -1, "", "", 1),
	Port_Property("s_axi_a_RVALID", 1, hls_out, -1, "", "", 1),
	Port_Property("s_axi_a_RREADY", 1, hls_in, -1, "", "", 1),
	Port_Property("s_axi_a_RDATA", 32, hls_out, -1, "", "", 1),
	Port_Property("s_axi_a_RRESP", 2, hls_out, -1, "", "", 1),
	Port_Property("s_axi_a_BVALID", 1, hls_out, -1, "", "", 1),
	Port_Property("s_axi_a_BREADY", 1, hls_in, -1, "", "", 1),
	Port_Property("s_axi_a_BRESP", 2, hls_out, -1, "", "", 1),
	Port_Property("interrupt", 1, hls_out, -1, "", "", 1),
};
const char* HLS_Design_Meta::dut_name = "runloops";
