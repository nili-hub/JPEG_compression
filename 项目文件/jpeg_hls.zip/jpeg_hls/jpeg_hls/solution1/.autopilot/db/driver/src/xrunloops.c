// ==============================================================
// File generated on Sat Aug 01 15:34:49 +0800 2020
// Vivado(TM) HLS - High-Level Synthesis from C, C++ and SystemC v2018.3 (64-bit)
// SW Build 2405991 on Thu Dec  6 23:38:27 MST 2018
// IP Build 2404404 on Fri Dec  7 01:43:56 MST 2018
// Copyright 1986-2018 Xilinx, Inc. All Rights Reserved.
// ==============================================================
/***************************** Include Files *********************************/
#include "xrunloops.h"

/************************** Function Implementation *************************/
#ifndef __linux__
int XRunloops_CfgInitialize(XRunloops *InstancePtr, XRunloops_Config *ConfigPtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(ConfigPtr != NULL);

    InstancePtr->A_BaseAddress = ConfigPtr->A_BaseAddress;
    InstancePtr->IsReady = XIL_COMPONENT_IS_READY;

    return XST_SUCCESS;
}
#endif

void XRunloops_Start(XRunloops *InstancePtr) {
    u32 Data;

    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XRunloops_ReadReg(InstancePtr->A_BaseAddress, XRUNLOOPS_A_ADDR_AP_CTRL) & 0x80;
    XRunloops_WriteReg(InstancePtr->A_BaseAddress, XRUNLOOPS_A_ADDR_AP_CTRL, Data | 0x01);
}

u32 XRunloops_IsDone(XRunloops *InstancePtr) {
    u32 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XRunloops_ReadReg(InstancePtr->A_BaseAddress, XRUNLOOPS_A_ADDR_AP_CTRL);
    return (Data >> 1) & 0x1;
}

u32 XRunloops_IsIdle(XRunloops *InstancePtr) {
    u32 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XRunloops_ReadReg(InstancePtr->A_BaseAddress, XRUNLOOPS_A_ADDR_AP_CTRL);
    return (Data >> 2) & 0x1;
}

u32 XRunloops_IsReady(XRunloops *InstancePtr) {
    u32 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XRunloops_ReadReg(InstancePtr->A_BaseAddress, XRUNLOOPS_A_ADDR_AP_CTRL);
    // check ap_start to see if the pcore is ready for next input
    return !(Data & 0x1);
}

void XRunloops_EnableAutoRestart(XRunloops *InstancePtr) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XRunloops_WriteReg(InstancePtr->A_BaseAddress, XRUNLOOPS_A_ADDR_AP_CTRL, 0x80);
}

void XRunloops_DisableAutoRestart(XRunloops *InstancePtr) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XRunloops_WriteReg(InstancePtr->A_BaseAddress, XRUNLOOPS_A_ADDR_AP_CTRL, 0);
}

u32 XRunloops_Get_return(XRunloops *InstancePtr) {
    u32 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XRunloops_ReadReg(InstancePtr->A_BaseAddress, XRUNLOOPS_A_ADDR_AP_RETURN);
    return Data;
}
u32 XRunloops_Get_image_r_BaseAddress(XRunloops *InstancePtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    return (InstancePtr->A_BaseAddress + XRUNLOOPS_A_ADDR_IMAGE_R_BASE);
}

u32 XRunloops_Get_image_r_HighAddress(XRunloops *InstancePtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    return (InstancePtr->A_BaseAddress + XRUNLOOPS_A_ADDR_IMAGE_R_HIGH);
}

u32 XRunloops_Get_image_r_TotalBytes(XRunloops *InstancePtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    return (XRUNLOOPS_A_ADDR_IMAGE_R_HIGH - XRUNLOOPS_A_ADDR_IMAGE_R_BASE + 1);
}

u32 XRunloops_Get_image_r_BitWidth(XRunloops *InstancePtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    return XRUNLOOPS_A_WIDTH_IMAGE_R;
}

u32 XRunloops_Get_image_r_Depth(XRunloops *InstancePtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    return XRUNLOOPS_A_DEPTH_IMAGE_R;
}

u32 XRunloops_Write_image_r_Words(XRunloops *InstancePtr, int offset, int *data, int length) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr -> IsReady == XIL_COMPONENT_IS_READY);

    int i;

    if ((offset + length)*4 > (XRUNLOOPS_A_ADDR_IMAGE_R_HIGH - XRUNLOOPS_A_ADDR_IMAGE_R_BASE + 1))
        return 0;

    for (i = 0; i < length; i++) {
        *(int *)(InstancePtr->A_BaseAddress + XRUNLOOPS_A_ADDR_IMAGE_R_BASE + (offset + i)*4) = *(data + i);
    }
    return length;
}

u32 XRunloops_Read_image_r_Words(XRunloops *InstancePtr, int offset, int *data, int length) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr -> IsReady == XIL_COMPONENT_IS_READY);

    int i;

    if ((offset + length)*4 > (XRUNLOOPS_A_ADDR_IMAGE_R_HIGH - XRUNLOOPS_A_ADDR_IMAGE_R_BASE + 1))
        return 0;

    for (i = 0; i < length; i++) {
        *(data + i) = *(int *)(InstancePtr->A_BaseAddress + XRUNLOOPS_A_ADDR_IMAGE_R_BASE + (offset + i)*4);
    }
    return length;
}

u32 XRunloops_Write_image_r_Bytes(XRunloops *InstancePtr, int offset, char *data, int length) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr -> IsReady == XIL_COMPONENT_IS_READY);

    int i;

    if ((offset + length) > (XRUNLOOPS_A_ADDR_IMAGE_R_HIGH - XRUNLOOPS_A_ADDR_IMAGE_R_BASE + 1))
        return 0;

    for (i = 0; i < length; i++) {
        *(char *)(InstancePtr->A_BaseAddress + XRUNLOOPS_A_ADDR_IMAGE_R_BASE + offset + i) = *(data + i);
    }
    return length;
}

u32 XRunloops_Read_image_r_Bytes(XRunloops *InstancePtr, int offset, char *data, int length) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr -> IsReady == XIL_COMPONENT_IS_READY);

    int i;

    if ((offset + length) > (XRUNLOOPS_A_ADDR_IMAGE_R_HIGH - XRUNLOOPS_A_ADDR_IMAGE_R_BASE + 1))
        return 0;

    for (i = 0; i < length; i++) {
        *(data + i) = *(char *)(InstancePtr->A_BaseAddress + XRUNLOOPS_A_ADDR_IMAGE_R_BASE + offset + i);
    }
    return length;
}

void XRunloops_InterruptGlobalEnable(XRunloops *InstancePtr) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XRunloops_WriteReg(InstancePtr->A_BaseAddress, XRUNLOOPS_A_ADDR_GIE, 1);
}

void XRunloops_InterruptGlobalDisable(XRunloops *InstancePtr) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XRunloops_WriteReg(InstancePtr->A_BaseAddress, XRUNLOOPS_A_ADDR_GIE, 0);
}

void XRunloops_InterruptEnable(XRunloops *InstancePtr, u32 Mask) {
    u32 Register;

    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Register =  XRunloops_ReadReg(InstancePtr->A_BaseAddress, XRUNLOOPS_A_ADDR_IER);
    XRunloops_WriteReg(InstancePtr->A_BaseAddress, XRUNLOOPS_A_ADDR_IER, Register | Mask);
}

void XRunloops_InterruptDisable(XRunloops *InstancePtr, u32 Mask) {
    u32 Register;

    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Register =  XRunloops_ReadReg(InstancePtr->A_BaseAddress, XRUNLOOPS_A_ADDR_IER);
    XRunloops_WriteReg(InstancePtr->A_BaseAddress, XRUNLOOPS_A_ADDR_IER, Register & (~Mask));
}

void XRunloops_InterruptClear(XRunloops *InstancePtr, u32 Mask) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XRunloops_WriteReg(InstancePtr->A_BaseAddress, XRUNLOOPS_A_ADDR_ISR, Mask);
}

u32 XRunloops_InterruptGetEnabled(XRunloops *InstancePtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    return XRunloops_ReadReg(InstancePtr->A_BaseAddress, XRUNLOOPS_A_ADDR_IER);
}

u32 XRunloops_InterruptGetStatus(XRunloops *InstancePtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    return XRunloops_ReadReg(InstancePtr->A_BaseAddress, XRUNLOOPS_A_ADDR_ISR);
}

