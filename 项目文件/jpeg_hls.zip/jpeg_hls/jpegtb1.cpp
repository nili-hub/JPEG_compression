#include "jpeghls.h"
int main(){
	FILE *fp;
		char buf[bufSize];  //50
		int rows, cols;
		int i,j;
		signed short int image [256][256][3];
		signed short int image_o [256][256][3];
		float cosMatrix[8][8];
		float subimgY[8][8], subimgC1[8][8], subimgC2[8][8];
		float quant_matrix[8][8];

		fp = fopen("F:/Xilinx_Train/jpeg_hls/ori.dat","r");

		//Successfully opened the file
		//line 1 has the rows and columns of the input matrix
		fgets(buf, sizeof(buf),fp); //��ȡ�ļ��еĵ�һ��
		buf[strlen(buf)-1]='\0';	//removes the newline fgets stores
		sscanf(buf, "%d %d", &rows, &cols);
		printf("%d %d\n", rows, cols);
		//Code to read the whole file and obtain the image
		for(i=0; i<rows; i++)
		{
			for(j=0; j<cols; j++)
			{
				fgets(buf, sizeof(buf),fp);
				buf[strlen(buf)-1]='\0';	//removes the newline fgets stores
				sscanf(buf, "%hu %hu %hu", &image[i][j][0], &image[i][j][1], &image[i][j][2]);// ��buf����image��
			}
		}

		runloops(image,image_o);
	return 0;

}
