#ifndef __JPEGHLS_H__
#define __JPEGHLS_H__

#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <math.h>
#include <ap_fixed.h>
#include <complex>
#include <fstream>

#define bufSize 50
#define PI 3.1415926535897932384626

int runloops(signed short int image[128][128][3]);

#endif 


