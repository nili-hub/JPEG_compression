// ==============================================================
// File generated on Sat Aug 01 15:34:49 +0800 2020
// Vivado(TM) HLS - High-Level Synthesis from C, C++ and SystemC v2018.3 (64-bit)
// SW Build 2405991 on Thu Dec  6 23:38:27 MST 2018
// IP Build 2404404 on Fri Dec  7 01:43:56 MST 2018
// Copyright 1986-2018 Xilinx, Inc. All Rights Reserved.
// ==============================================================
// a
// 0x00000 : Control signals
//           bit 0  - ap_start (Read/Write/COH)
//           bit 1  - ap_done (Read/COR)
//           bit 2  - ap_idle (Read)
//           bit 3  - ap_ready (Read)
//           bit 7  - auto_restart (Read/Write)
//           others - reserved
// 0x00004 : Global Interrupt Enable Register
//           bit 0  - Global Interrupt Enable (Read/Write)
//           others - reserved
// 0x00008 : IP Interrupt Enable Register (Read/Write)
//           bit 0  - Channel 0 (ap_done)
//           bit 1  - Channel 1 (ap_ready)
//           others - reserved
// 0x0000c : IP Interrupt Status Register (Read/TOW)
//           bit 0  - Channel 0 (ap_done)
//           bit 1  - Channel 1 (ap_ready)
//           others - reserved
// 0x00010 : Data signal of ap_return
//           bit 31~0 - ap_return[31:0] (Read)
// 0x20000 ~
// 0x3ffff : Memory 'image_r' (49152 * 16b)
//           Word n : bit [15: 0] - image_r[2n]
//                    bit [31:16] - image_r[2n+1]
// (SC = Self Clear, COR = Clear on Read, TOW = Toggle on Write, COH = Clear on Handshake)

#define XRUNLOOPS_A_ADDR_AP_CTRL      0x00000
#define XRUNLOOPS_A_ADDR_GIE          0x00004
#define XRUNLOOPS_A_ADDR_IER          0x00008
#define XRUNLOOPS_A_ADDR_ISR          0x0000c
#define XRUNLOOPS_A_ADDR_AP_RETURN    0x00010
#define XRUNLOOPS_A_BITS_AP_RETURN    32
#define XRUNLOOPS_A_ADDR_IMAGE_R_BASE 0x20000
#define XRUNLOOPS_A_ADDR_IMAGE_R_HIGH 0x3ffff
#define XRUNLOOPS_A_WIDTH_IMAGE_R     16
#define XRUNLOOPS_A_DEPTH_IMAGE_R     49152

